const Videos = (props) =>{
    return(
        <>    
                <div className="embed-responsive embed-responsive-16by9">
                    <iframe className="embed-responsive-item" src={props.links}></iframe>
                </div>               
        </>
    );
}

export default Videos;
